#define F_CPU 8000000UL
#define get_bit(reg,bitnum) ((reg & (1<<bitnum))>>bitnum) // get bit macro used to get the value of a certain bit.
#include <avr/io.h>
#include <util/delay.h>

void TWI_Init (void);
void TWI_Start (void);
void TWI_Stop (void);
void TWI_Write (unsigned char data);
void TWI_Read_Nack (unsigned char* ptr);
void EEPROM_Write (unsigned char data, unsigned char address);
void EEPROM_Read (unsigned char address, unsigned char* ptr);
void EEPROM_Write_Balance(unsigned int num);


void TWI_Init (void)
{
	//set_bit(TWCR,6);
	TWSR=0;
	TWBR=0x07;
	TWCR|=(1<<TWEN);
}


void TWI_Start (void)
{
	TWCR= (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while (get_bit(TWCR,TWINT)==0)
	{
	}
}


void TWI_Stop (void)
{
	TWCR=(1<<TWSTO)|(1<<TWEN)|(1<<TWINT);
}

void TWI_Write (unsigned char data)
{
	TWDR=data;
	TWCR= (1<<TWINT)|(1<<TWEN);
	while (get_bit(TWCR,TWINT)==0)
	{
	}
}


void TWI_Read_Nack (unsigned char* ptr) // The function argument is a pointer to a memory place in the MCU to store the received data in
{
	TWCR=(1<<TWINT)|(1<<TWEN);
	while (get_bit(TWCR,TWINT)==0)
	{
	}
	*ptr=TWDR;
}


void EEPROM_Write (unsigned char data,unsigned char address)
{
	TWI_Start();
	TWI_Write(0xA8); //slave address is 1010.100 and a 0 in the 8th bit to indicate Writting.
	TWI_Write(address);
	TWI_Write(data);
	TWI_Stop();
}

void EEPROM_Read (unsigned char address, unsigned char* ptr) // the function arguments are an address in the EEPROM to read from
//and a pointer to a memory place in the MCU to store the read data in
{
	TWI_Start();
	TWI_Write(0xA8);
	TWI_Write(address);
	TWI_Start();
	TWI_Write(0xA9);
	TWI_Read_Nack(ptr);
	TWI_Stop();
}

void EEPROM_Write_Balance(unsigned int num)
{
	unsigned int digit_int[5],l;
	unsigned char  digit_char[5];
	for(l=0; num!=0;l++)
	{
		digit_int[l]=num%10;
		num=num/10;
		digit_char[l]=digit_int[l]+48;
		EEPROM_Write(digit_char[l],l);
		_delay_ms(10);
	}
/*	for(l=l-1;l>=0;l--)
	{
		EEPROM_Write(digit_char[l], l);
		_delay_ms(10);
	}*/
}