//--- F_CPU & BAUD RATE ---//
#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include "lcd.h"
#include "Keypad.h"
#include "Usart.h"
#include "AES.h"

void encrypt_feedback(unsigned char);
//Global Declaration for Master
char C_R;
//Global declaration for Card
uint16_t balance;
unsigned char feedback;
unsigned char ciphertext[17];
short int j;

//Global Declaration for Reader Machine
char key[3]={0,0,0};							//Input transaction amount
//unsigned int balance;
int InputAmt;
unsigned char feedback_code;
char Card_Op;
unsigned char msg[16];
unsigned char ciphertext[17];
int IntFlag;

//Function declaration for reader machine
void DisplayBalance();
void AskAmount();
void DisplayComplete();
void HomeScreen();
void GetAmount();
void Encrypt(char);
void dis_encypt_msg();
void feedback_Reader(unsigned char);
void decrypt_feedback();
void dis_decypt_msg();
void clearlcd();
void soft_reset();


unsigned char check_pw()
{
	uint16_t tran_amt;
	balance = eeprom_read_word((uint16_t *) 200);
	if(rx_data[0]=='A'&& rx_data[1]=='M'&& rx_data[2]=='P' && rx_data[3]=='S')     //1st 2nd 3rd and 4th digit act as password
	{
		tran_amt= (rx_data[6]-48)*100+(rx_data[7]-48)*10+(rx_data[8]-48);		//Calculating Transaction amount
		if(rx_data[9]=='1')												 //1: Recharge in the 10th digit
		{
			balance+=tran_amt;
			eeprom_update_word((uint16_t *) 200, balance);	//writing the balance to eeprom, in the memory address 20 in EEPROM
			return 's';											//s Feedback signal: Recharge Successful
		}
		else
		{
			if(tran_amt<balance)					//Payment if balance is greater than Transaction amount
			{
				balance-=tran_amt;
				eeprom_update_word((uint16_t *) 200, balance);	//writing the balance to eeprom, in the memory address 20 in EEPROM
				return 's';						//s signals payment successful
			}
			else
			return 'i';							//i signals insufficient balance
		}
	}
	else
	return '0';										//Authentication Error
}

ISR(USART_RXC_vect)
{
	usart_msg_rx();						//--- Usart Receiving
	//ISR for Card
	if(C_R=='2')
	{
		unsigned char keyT[]   = "A405M414P429S445";
		aes_enc_dec(rx_data, keyT, 1);			//1 for decryption
		feedback= check_pw();
		encrypt_feedback(feedback);
		switch(feedback)
		{
			case 's':
				DisplayComplete();
				break;
			case 'i':
				LCD_Write_String("Insuff. Fund");
				_delay_ms(500);
				break;
			case '0':
				LCD_Write_String("Auth... Err");
				_delay_ms(500);
				break;
			default:
				LCD_Write_String("Undefined Err");
				_delay_ms(500);
				break;
		}
	}
	if(C_R=='1')
	{
		//ISR for Reader
		unsigned char keyF[]="PUL074BEX5142945";
		aes_enc_dec(rx_data,keyF,1);
		feedback_code=rx_data[5];
	
	}
	IntFlag=0;	
}

void card()
{
	IntFlag=1;
	//Setting interrupt
	DDRD |=1<<PIND1;
	//Initial initialization of the balance
	//eeprom_update_word((uint16_t*) 200, 999);
	balance = eeprom_read_word((uint16_t *) 200);		//getting balance from EEPROM
	clearlcd();
	while(IntFlag)
	{
		LCD_cmd(0x80);
		LCD_Write_String("Show Reader...");
		_delay_ms(10);
	}		
}

void encrypt_feedback(unsigned char c)
{
	for(j=0;j<16;j++)
	ciphertext[j]=rx_data[j];
	ciphertext[5]= c;
	unsigned char keyF[]="PUL074BEX5142945";
	aes_enc_dec(ciphertext,keyF,0);
	ciphertext[j]=0;
	usart_msg_tx(&ciphertext[0]);
}

void reader(void)
{
		IntFlag=1;
		//Keypad Initialize
		KeypadInit();
		InputAmt=0;
		HomeScreen();
		Encrypt(Card_Op);
		LCD_Write_String("Show the Card...");
		_delay_ms(500);
		usart_msg_tx(&ciphertext[0]);				//send encrypted message
		while(IntFlag)
		{
			clearlcd();	
		}
		feedback_Reader(feedback_code);

}



void HomeScreen()
{
	DisplayBalance();
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(5);
	LCD_Write_String("Select Option:");
	_delay_ms(5);
	LCD_cmd(0x90);			// move cursor to the beginning of the 3rd row
	_delay_ms(5);
	LCD_Write_String("Recharge(+)");
	_delay_ms(5);
	LCD_cmd(0xD0);			// move cursor to the beginning of the 4th row
	LCD_Write_String("Withdraw(-):  ");
	_delay_ms(5);	
	do
	{
	 Card_Op= GetKey();
	}while(!(Card_Op=='+'||Card_Op=='-'));
	LCD_write(Card_Op);
	_delay_ms(100);
	clearlcd();
	LCD_Write_String("ENTER AMOUNT(");
	_delay_ms(10);
	LCD_write(Card_Op);
	LCD_Write_String("):");
	_delay_ms(10);
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_cmd(0x0E);			//display on, cursor on
	_delay_ms(10);
	GetAmount();
	clearlcd();
}

void GetAmount()
{
	uint8_t i=0, j=0;
	short int x=0;
	do
	{
		KeypadInit();
		do
		{
			key[i]= GetKey();
		}while(key[i]==0);
	
	 x = (key[i]-48);
	j=i;		
	if(x>=0 && x<10)
		{
			//InputAmt = InputAmt*10 + x;
			LCD_write(key[i]);
			i++;
		}
	if(key[i]=='/')
	{
		key[i]=0;
		LCD_cmd(0x10);
		_delay_ms(10);
		LCD_write(key[i]);
		LCD_cmd(0x10);
		_delay_ms(10);
		i--;
	}
	}while(key[j]!='=');
}

void Encrypt(char c)
{
	int j;
	unsigned char keyT[]   = "A405M414P429S445";
	//Encrypt the key pressed along with the authentication password
	//Assigning password
	msg[0]='A';
	msg[1]='M';
	msg[2]='P';
	msg[3]='S';

	//Random Value
	unsigned int Random= TCNT1;
	msg[4]=Random%9+48;
	msg[5]=Random%11+50;
	msg[10]=Random%13+40;
	msg[11]=Random%17+48;
	msg[12]=Random%26+60;
	msg[13]=Random%32+80;
	msg[14]=Random%26+48;
	msg[15]=Random%32+58;
	//Input Amount	
	short int q,r;	
	unsigned char temp;		
	for(q=0;q<3;q++)
	{
		if(key[q]=='=')
		{
			for(r=q;r<3;r++)
				key[r]='0';
			for(r=q;r<3;r++)
				{
					temp=key[2];
					key[2]=key[1];
					key[1]=key[0];
					key[0]=temp;
				}
		}
	}
	msg[6]=key[0];
	msg[7]=key[1];
	msg[8]=key[2];
	InputAmt=(key[0]-48)*100+(key[1]-48)*10+(key[2]-48);
	if(InputAmt>balance)
	{
		clearlcd();
		LCD_Write_String("Insuff. Fund");
		_delay_ms(500);
		soft_reset();
	}
	//Pay or Recharge
	if (c=='+')		msg[9]='1';				//'1': to recharge the card
	if(c=='-')		msg[9]='0';				//'0': to withdraw cash
	
aes_enc_dec(msg,keyT,0);				//0 for Encryption
for(j=0;j<16;j++)
	ciphertext[j]=msg[j];
ciphertext[j]=0;
}



void feedback_Reader(unsigned char x)
{
	clearlcd();
	LCD_Write_String("Processing...");
	_delay_ms(500);
	clearlcd();
	switch(x)
	{
		case 's':
			if(Card_Op=='-')		balance += InputAmt;
			if(Card_Op=='+')		balance -= InputAmt;
			eeprom_update_word((uint16_t *) 200, balance);
			DisplayComplete();
			break;
		case 'i':
			LCD_Write_String("Insuff. Fund");
			_delay_ms(500);
			break;
		case '0':
			LCD_Write_String("Auth... Err");
			_delay_ms(500);
			break;
		default:
			LCD_Write_String("Undefined Err");
			_delay_ms(500);
			break;
	}
}

void DisplayComplete()
{
	clearlcd();
	LCD_Write_String("Transaction");
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_Write_String("Complete.");
	_delay_ms(500);
}

void DisplayBalance()
{
	clearlcd();
	LCD_Write_String("Balance:  ");
	_delay_ms(10);
	LCD_int_display(balance);
}
void clearlcd()
{
	LCD_cmd(0x01);				//Clear Screen
	_delay_ms(10);
}
void soft_reset()
{
	do
	{
		wdt_enable(WDTO_15MS);
		for(;;)
		{
		}
	}while(0);
}


int main()
{
	//Setting for LCD
	DDRB=0xFF;              // set LCD data port as output
	DDRD=0xE2;              // set LCD signals (RS, RW, E) as out put
	TCCR1B |= 1<<CS10;		//for internal clock for random value generation
	
	//Usart initialization
	usart_init();						//--- Usart initializing
	sei();
	//Initial initialization of the balance
	eeprom_update_word((uint16_t *) 200, 10000);	//writing the balance to eeprom, in the memory address 20 in EEPROM
	balance = eeprom_read_word((uint16_t *) 200);		//getting balance from EEPROM
	//LCD initialization
	init_LCD();             // initialize LCD
	_delay_ms(10);         // delay of 10 Milli seconds
	LCD_cmd(0x0C);			//display on, cursor off
	_delay_ms(10);
	while(1)
	{
		KeypadInit();
		DisplayBalance();
		LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
		_delay_ms(5);
		LCD_Write_String("Communicate With");
		_delay_ms(5);
		LCD_cmd(0x90);			// move cursor to the beginning of the 3rd row
		_delay_ms(5);
		LCD_Write_String("1.Card ");
		_delay_ms(5);
		LCD_cmd(0xD0);			// move cursor to the beginning of the 4th row
		LCD_Write_String("2.Reader:  ");
		_delay_ms(5);
		do
		{
			C_R= GetKey();
		}while(!(C_R=='1'||C_R=='2'));
		LCD_write(C_R);
		_delay_ms(100);
		LCD_cmd(0x01);			//Clear Display
		_delay_ms(10);
		if(C_R=='1')	reader();
		if(C_R=='2')	card();
		
	}
}