
char data[20];
short int i=0;

void usart_init()
{
	UBRRH = 0x00;						//--- Initialize UBRR value for Baud Rate
	UBRRL = 0x33;						//--- Baud Rate Set as 9600 by Data Sheet
	UCSRB = (1<<TXEN) | (1<<RXEN);		//--- Transmit and Receive Enable
	UCSRC = (1<<URSEL) | (3<<UCSZ0);	//--- 8 bit data and UCSRC is selected
}

void usart_tx(char x)
{
	UDR = x;							//--- Move data to UDR Data Reg
	while (!(UCSRA & (1<<UDRE)));		//--- Check whether UDR is empty
}

char usart_rx()
{
	while (!(UCSRA & (1<<RXC)));		//--- Check whether Receive is complete
	return(UDR);						//--- Return Data from UDR
}

void usart_msg_tx(char *c)
{
	do
	{
		usart_tx(*c++);					//--- Increment the pointer
	} while (*(c-1)!= 0);
	
}

void usart_msg_rx()
{
	do
	{
		data[i]=usart_rx();
		i++;
	} while (data[i-1]!=0);
	
}