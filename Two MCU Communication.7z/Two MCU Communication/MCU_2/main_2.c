//--- F_CPU & BAUD RATE ---//
#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate

#include <avr/io.h>			//--- Include Reg file of Atmega16
#include "Usart.h"

char data[20];

//--- Main Program ---//
int main(void)
{
	usart_init();						//--- Usart initializing
	usart_msg_tx("Rx:");
	usart_msg_rx();
	usart_msg_tx("OK");
	usart_tx(0x0d);						//--- New Line
	usart_msg_tx(&data[0]);
	while(1)
	{		
	}
	return 0;
}

