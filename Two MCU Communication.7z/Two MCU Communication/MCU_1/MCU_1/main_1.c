#include <avr/io.h>			//--- Include Reg file of Atmega16

//--- F_CPU & BAUD RATE ---//

#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate

//--- Proto Type Declaration ---//

void usart_init(void);		//--- Usart Initialize
void usart_tx(char x);		//--- Usart Transmit
char usart_rx(void);		//--- Usart Receive
void usart_msg(char *c);	//--- Usart Transmit String

//--- Glodal Delecaration ---//

//char data;

//--- Main Program ---//

int main(void)
{
	usart_init();						//--- Usart initializing
	usart_msg("Hello world");				//--- send the received data back	
	while(1)
	{
	}
}

//--- Proto Type Declaration ---//

void usart_init()
{
	UBRRH = 0x00;						//--- Initialize UBRR value for Baud Rate
	UBRRL = 0x33;						//--- Baud Rate Set as 9600 by Data Sheet
	UCSRB = (1<<TXEN) | (1<<RXEN);		//--- Transmit and Receive Enable
	UCSRC = (1<<URSEL) | (3<<UCSZ0);	//--- 8 bit data and UCSRC is selected
}

void usart_tx(char x)
{
	UDR = x;							//--- Move data to UDR Data Reg
	while (!(UCSRA & (1<<UDRE)));		//--- Check whether UDR is empty
}

char usart_rx()
{
	while (!(UCSRA & (1<<RXC)));		//--- Check whether Receive is complete
	return(UDR);						//--- Return Data from UDR
}

void usart_msg(char *c)
{
	while (*c != 0)						//--- Check for null
	usart_tx(*c++);					//--- Increment the pointer
}
