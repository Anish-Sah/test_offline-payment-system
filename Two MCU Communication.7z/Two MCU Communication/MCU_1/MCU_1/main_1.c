//--- F_CPU & BAUD RATE ---//
#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate

#include <avr/io.h>			//--- Include Reg file of Atmega16
#include "Usart.h"


char data[20]={'H','E','L','L','O',' ','W','O','R','L','D'};

//--- Main Program ---//
int main(void)
{
	usart_init();						//--- Usart initializing
	usart_msg_tx(&data[0]);				//--- Transmitting array
	while(1)
	{	
	}
}
