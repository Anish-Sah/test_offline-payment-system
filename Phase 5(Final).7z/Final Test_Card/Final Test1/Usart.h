
unsigned char rx_data[16];

void usart_init()
{
	UBRRH = 0x00;						//--- Initialize UBRR value for Baud Rate
	UBRRL = 0x33;						//--- Baud Rate Set as 9600 by Data Sheet
	UCSRB = (1<<TXEN) | (1<<RXEN);		//--- Transmit and Receive Enable
	UCSRC = (1<<URSEL) | (3<<UCSZ0);	//--- 8 bit data and UCSRC is selected
	UCSRB |= (1 << RXEN) | (1 << RXCIE); //-- Enabling interrupt

}

void usart_tx(unsigned char x)
{
	UDR = x;							//--- Move data to UDR Data Reg
	while (!(UCSRA & (1<<UDRE)));		//--- Check whether UDR is empty
}

unsigned char usart_rx()
{
	while (!(UCSRA & (1<<RXC)));		//--- Check whether Receive is complete
	return(UDR);						//--- Return Data from UDR
}

void usart_msg_tx(unsigned char *c)
{
	do
	{
		usart_tx(*c++);					//--- Increment the pointer
	} while (*(c-1)!= 0);
	
}

void usart_msg_rx()
{
	short int i=0;
	do
	{
		rx_data[i]=usart_rx();
		i++;
	} while (rx_data[i-1]!=0);
	
}
void usart_sec_tx(unsigned char *c)
{
	short int count=0;
	do
	{
		usart_tx(*c++);					//--- Increment the pointer
		count++;
	} while (count<16);
	
}