#define  F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "lcd.h"
#include "Keypad.h"

char key[3]={0,0,0};							//Input transaction amount
unsigned int balance = 1000;
int InputAmt=0;
char msg[10];									//Encrypted message to be transmitted
char feedback_code='s';
char Pay_Get;


void DisplayBalance();
void AskAmount();
void DisplayComplete();
void HomeScreen();
void GetAmount();
void Encrypt(char);
void dis_encypt_msg();
void feedback(char);


int main(void)
{
	//Setting for LCD
	DDRB=0xFF;              // set LCD data port as output
	DDRD=0xE4;              // set LCD signals (RS, RW, E) as out put
	
	//Setting interrupt
	PORTD |=1<<PIND3;
	GICR |= 1<<INT1;
	sei();
	//Keypad Initialize
	KeypadInit();
		
	//LCD initialization
	init_LCD();             // initialize LCD
	_delay_ms(10);         // delay of 10 Milli seconds
	LCD_cmd(0x0C);			//display on, cursor off
	_delay_ms(10);
	HomeScreen();
	Encrypt(Pay_Get);
	LCD_Write_String("Show the Card...");
	_delay_ms(2000);
	//dis_encypt_msg();
	feedback(feedback_code);					//Assuming as feedback signal
	while(1)
	{
	}
	return 0;
}



void HomeScreen()
{
	DisplayBalance();
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_Write_String("Pay(-)/Get(+)? ");
	_delay_ms(10);
	do
	{
	 Pay_Get= GetKey();
	}while(!(Pay_Get=='+'||Pay_Get=='-'));
	LCD_write(Pay_Get);
	_delay_ms(100);
	LCD_cmd(0x01);			//Clear Display
	_delay_ms(10);
	LCD_Write_String("ENTER AMOUNT(");
	_delay_ms(10);
	LCD_write(Pay_Get);
	LCD_Write_String("):");
	_delay_ms(10);
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_cmd(0x0E);			//display on, cursor on
	_delay_ms(10);
	GetAmount();
	LCD_cmd(0x01);
	_delay_ms(10);

}

void GetAmount()
{
	uint8_t i=0, j=0;
	short int x=0;
	do
	{
		KeypadInit();
		do
		{
			key[i]= GetKey();
		}while(key[i]==0);
	 x = (key[i]-48);
	j=i;		
	if(x>=0 && x<10)
		{
			InputAmt = InputAmt*10 + x;
			LCD_write(key[i]);
			i++;
		}
	}while(key[j]!='=');
}

void Encrypt(char c)
{
	//Encrypt the key pressed along with the authentication password
	//Assigning password
	msg[0]='1';
	msg[1]='2';
	msg[2]='3';
	msg[3]='4';
	//Random Value
	msg[4]='9';				
	msg[5]='2';	
	//Input Amount			
	msg[6]=key[0];
	msg[7]=key[1];
	msg[8]=key[2];
	//Pay or Recharge
	if (c=='+')		msg[9]='0';				//'0': to reduce the balance in the card
	if(c=='-')		msg[0]='1';	
}

/*
void dis_encypt_msg()
{
	LCD_cmd(0x01);			//Clear Display
	_delay_ms(10);
	for(int k=0;k<10;k++)
		LCD_write(msg[k]);
}
*/

void feedback(char x)
{
	LCD_cmd(0x01);
	_delay_ms(10);	
	LCD_Write_String("Processing...");
	_delay_ms(2000);
	LCD_cmd(0x01);
	_delay_ms(10);
	switch(x)
	{
		case 's':
			if(Pay_Get=='+')		balance += InputAmt;
			if(Pay_Get=='-')		balance -= InputAmt;
			DisplayComplete();
			break;
		case 'i':
			LCD_Write_String("Insuff. Fund");
			_delay_ms(3000);
			break;
		case '0':
			LCD_Write_String("Auth... Err");
			_delay_ms(3000);
			break;
		default:
			LCD_Write_String("Undefined Err");
			_delay_ms(3000);
			break;
	}
	HomeScreen();
}

void DisplayComplete()
{
	LCD_cmd(0x01);				//Clear Screen
	_delay_ms(10);
	LCD_Write_String("Transaction");
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_Write_String("Complete.");
	_delay_ms(1000);
}

void DisplayBalance()
{
	LCD_cmd(0x01);
	_delay_ms(10);
	LCD_Write_String("Balance:  ");
	_delay_ms(10);
	LCD_int_display(balance);
}