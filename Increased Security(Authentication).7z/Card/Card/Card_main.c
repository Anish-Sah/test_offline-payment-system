//--- F_CPU & BAUD RATE ---//
#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "Usart.h"
#include "Display7Seg.h"
#include "AES.h"
#include "ExtEeprom.h"

void encrypt_feedback(unsigned char);
void verify_reader();

uint16_t balance;
unsigned char feedback;							//to store the feedback of the transaction: success/failure 
unsigned char ciphertext[17];					//to store encrypted feedback sent to reader machine 
short int step;
unsigned char verify_code[17];
unsigned char msg[16];									//to store Encrypted Message
short int authenticity;
short int step;
short int j;



unsigned char check_pw()						//Checking the authenticity of the reader and performing transaction
{
	uint16_t tran_amt;
	balance = eeprom_read_word((uint16_t *) 200);	
	if(rx_data[0]=='A'&& rx_data[1]=='M'&& rx_data[2]=='P' && rx_data[3]=='S')     //1st 2nd 3rd and 4th digit act as password
	{
		tran_amt= (rx_data[6]-48)*100+(rx_data[7]-48)*10+(rx_data[8]-48);		//Calculating Transaction amount
		if(rx_data[9]=='1')														//1: Recharge in the 10th digit
			{
				balance+=tran_amt;
				eeprom_update_word((uint16_t *) 200, balance);	//writing the balance to eeprom, in the memory address 200
				EEPROM_Write_Balance(balance);					//Writing Balance on External EEprom at default address 0x00
				return 's';											//s Feedback signal: Recharge Successful
			}
		else 
			{
				if(tran_amt<balance)					//Payment if balance is greater than Transaction amount
					{
						balance-=tran_amt;
						eeprom_update_word((uint16_t *) 200, balance);	//writing the balance to eeprom, in the memory address 20 in EEPROM
						EEPROM_Write_Balance(balance);					//Writing Balance on External EEprom at default address 0x00
						return 's';										//s signals payment successful
					}
				else
					return 'i';											//i signals insufficient balance
			}					
	}
	else
		return '0';													//Authentication Error
}

ISR(USART_RXC_vect)
{
	usart_msg_rx();											//--- Usart Receiving
//	unsigned char keyT[]  = "A405M414P429S445";		//Transmission Secret Key
	unsigned char keyV[]  = "a405m414p429s445";
	switch(step)
	{
		case 1:													//Verifying itself
			aes_enc_dec(rx_data, keyV, 1);						//1 for decryption
			rx_data[16]=0;
			usart_msg_tx(&rx_data[0]);
			step=2;
			_delay_ms(100);
			break;
		case 2:													//Verifying the Reader
			for(j=0;j<16;j++)
			{
				if(verify_code[j]!=rx_data[j])
				{
					step=1;
					break;
				}
				step=3;
			}
			break;
		case 3:													//Trasaction
//			aes_enc_dec(rx_data, keyT, 1);						//1 for decryption
			feedback= check_pw();
			encrypt_feedback(feedback);							//Encrypting and transmitting feedback to the reader
			//Display Transaction success or failure for 5 Seconds
				uint8_t counter=0;
				TCCR1B |= 1<<CS10;
				while(counter<40)
				{
					while(TCNT1<60000)
					{
						counter++;
						if(feedback== 's')	led_display_succ();
						if(feedback== 'i' || feedback == '0')	led_display_fail();
					}
					TCNT1 =0;
					counter ++;
				}
			step=1;
			break;
	}
}

int main()
{
	//Setting interrupt
	DDRD |=1<<PIND1;
	usart_init();						//--- Usart initializing
	sei();
	//Initial initialization of the balance
	eeprom_update_word((uint16_t*) 200, 500);			//Initial balance
	balance = eeprom_read_word((uint16_t *) 200);		//getting balance from EEPROM
	step=1;
	while(1)
	{
		led_display(balance);
		if(step==2) verify_reader();
		//Jump to ISR for transaction when Receiving interrupt is triggered 
	}
	return 0;
	
}

void encrypt_feedback(unsigned char c)				
{
	for(j=0;j<16;j++)
		ciphertext[j]=rx_data[j];
	ciphertext[5]= c;
//	unsigned char keyF[]="PUL074BEX5142945";		//Secret Key for Encrypting Feedback Signal
//	aes_enc_dec(ciphertext,keyF,0);
	ciphertext[j]=0;
	usart_msg_tx(&ciphertext[0]);					//Sending encrypted feedback to the reader
}

void verify_reader()
{
	unsigned char keyV[] = "a405m414p429s445";
	unsigned int Random= TCNT1;
	for(int k=0;k<16;k++)
	{
		verify_code[k]=Random%(9+k)+48;
		msg[k]=verify_code[k];
	}
	verify_code[16]=0;
	//Encrypting
	aes_enc_dec(msg,keyV,0);				//0 for Encryption
	for(j=0;j<16;j++)
		ciphertext[j]=msg[j];
	ciphertext[j]=0;
	usart_msg_tx(&ciphertext[0]);				//send encrypted verification message
}