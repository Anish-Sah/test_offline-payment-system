//--- F_CPU & BAUD RATE ---//
#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate


#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include "lcd.h"
#include "Keypad.h"
#include "Usart.h"
#include "AES.h"
#include "ExtEeprom.h"

char key[3]={0,0,0};									//to store entered keys for transaction amount 
unsigned int balance;									//to store balance
int InputAmt;											//to store entered amount
unsigned char feedback_code;							//to store feedback from Card
char Pay_Get;											
unsigned char msg[16];									//to store Encrypted Message
unsigned char ciphertext[17];
int IntFlag;											//to wait for feedback
short int SVerifyFlag;
unsigned char verify_code[17];
short int authenticity; 
short int step;
short int j;


void DisplayBalance();									//display current balance in lcd
void AskAmount();										//display "enter amount" in lcd
void DisplayComplete();									//display "transaction complete" in lcd
void HomeScreen();										//Homescreen	
void GetAmount();										//get input amount
void Encrypt(char);										//Encrypt message to send
void feedback(unsigned char);							//calculation according to feedback
void clearlcd();										//to clear lcd display
void reset();
void soft_reset();	
void verify_card();



ISR(USART_RXC_vect)
{
	usart_msg_rx();										//receiving encrypted feedback
	unsigned char keyV[]="a405m414p429s445";
//	unsigned char keyF[]="PUL074BEX5142945";			//secret feedback decryption key		
	switch(step)
	{
		case 1:											//Verifying the Card
			for(j=0;j<16;j++)
			{
				if(verify_code[j]!=rx_data[j])
					{
						authenticity=0;
						break;
					}	
				authenticity=1;
			}
			step=2;
			break;
		case 2:											//Verifying itself
			aes_enc_dec(rx_data, keyV, 1);						//1 for decryption
			rx_data[16]=0;
			usart_msg_tx(&rx_data[0]);
			step=3;
			SVerifyFlag=0;
			_delay_ms(10);
			break;
		case 3:											//Transaction
//			aes_enc_dec(rx_data,keyF,1);						//1: decoding feedback
			feedback_code=rx_data[5];
			break;
		default:
			break;
	}
IntFlag=0;
}

int main(void)
{
	//Setting for LCD
	DDRB=0xFF;              // set LCD data port as output
	DDRD=0xE2;              // set LCD signals (RS, RW, E) as out put
	TCCR1B |= 1<<CS10;		//for internal clock for random value generation	
	//Usart initialization
	usart_init();						//--- Usart initializing
	sei();
	//Initial initialization of the balance
	eeprom_update_word((uint16_t *) 200, 200);				//writing the balance to eeprom, in the memory address 20 in EEPROM
	balance = eeprom_read_word((uint16_t *) 200);		//getting balance from EEPROM
	//LCD initialization
	init_LCD();             // initialize LCD
	_delay_ms(10);         // delay of 10 Milli seconds
	LCD_cmd(0x0C);			//display on, cursor off
	_delay_ms(10);
	
	while(1)
	{
		IntFlag=1;
		SVerifyFlag=1;
		KeypadInit();							//Keypad Initialize					
		InputAmt=0;
		HomeScreen();
		verify_card();	
		while(SVerifyFlag);						//waiting for self verification	
		Encrypt(Pay_Get);
		clearlcd();
		LCD_Write_String("Show the Card...");
		_delay_ms(500);	
		usart_msg_tx(&ciphertext[0]);				//send encrypted message	
		IntFlag=1;	
		while(IntFlag)								//wait until feedback is received 
		{
				clearlcd();	
		}
		feedback(feedback_code);
	}
	return 0;
}


void HomeScreen()
{
	DisplayBalance();
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_Write_String("Pay(-)/Get(+)? ");
	_delay_ms(10);
	do
	{
	 Pay_Get= GetKey();
	}while(!(Pay_Get=='+'||Pay_Get=='-'));
	LCD_write(Pay_Get);
	_delay_ms(100);
	clearlcd();
	LCD_Write_String("ENTER AMOUNT(");
	_delay_ms(10);
	LCD_write(Pay_Get);
	LCD_Write_String("):");
	_delay_ms(10);
	LCD_cmd(0xC0);			// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_cmd(0x0E);			//display on, cursor on
	_delay_ms(10);
	GetAmount();
	clearlcd();

}

void GetAmount()
{
	uint8_t i=0, j=0;
	short int x=0;
	do
	{
		KeypadInit();
		do
		{
			key[i]= GetKey();
		}while(key[i]==0);
	
	 x = (key[i]-48);
	j=i;		
	if(x>=0 && x<10)
		{
			LCD_write(key[i]);
			i++;
		}
	if(key[i]=='/')
	{
		key[i]=0;
		LCD_cmd(0x10);					//move cursor left by one position
		_delay_ms(10);
		LCD_write(key[i]);
		LCD_cmd(0x10);					//move cursor left by one position
		_delay_ms(10);
		i--;
	}
	}while(key[j]!='=');
	//checking for sufficient balance
	//Input Amount
	short int q,r;
	unsigned char temp;
	for(q=0;q<3;q++)
	{
		if(key[q]=='=')
		{
			for(r=q;r<3;r++)
			key[r]='0';
			for(r=q;r<3;r++)
			{
				temp=key[2];
				key[2]=key[1];
				key[1]=key[0];
				key[0]=temp;
			}
		}
	}
	InputAmt=(key[0]-48)*100+(key[1]-48)*10+(key[2]-48);
	if(InputAmt>balance)
	{
		clearlcd();
		LCD_Write_String("Insuff. Fund");
		_delay_ms(500);
		soft_reset();
	}
}

void Encrypt(char c)
{
//	unsigned char keyT[]   = "A405M414P429S445";
	//Assigning password
	msg[0]='A';
	msg[1]='M';
	msg[2]='P';
	msg[3]='S';

	//Random Value
	unsigned int Random= TCNT1;
	msg[4] =Random%9+48;
	msg[5] =Random%11+50;
	msg[10]=Random%13+40;
	msg[11]=Random%17+48;
	msg[12]=Random%26+60;
	msg[13]=Random%32+80;
	msg[14]=Random%26+48;
	msg[15]=Random%32+58;
	
	msg[6]=key[0];
	msg[7]=key[1];
	msg[8]=key[2];

	//Pay or Recharge
	if (c=='+')		msg[9]='0';				//'0': to reduce the balance in the card
	if(c=='-')		msg[9]='1';	

//Encrypting
//aes_enc_dec(msg,keyT,0);				//0 for Encryption
for(j=0;j<16;j++)
	ciphertext[j]=msg[j];
ciphertext[j]=0;
}


void feedback(unsigned char x)
{
	clearlcd();	
	LCD_Write_String("Processing...");
	_delay_ms(500);
	clearlcd();
	switch(x)
	{
		case 's':
			if(Pay_Get=='+')		balance += InputAmt;
			if(Pay_Get=='-')		balance -= InputAmt;
			eeprom_update_word((uint16_t *) 200, balance);			//writing balance on internal eeprom of mcu
			EEPROM_Write_Balance(balance);							//Writing Balance on External EEprom at default address 0x00
			DisplayComplete();
			break;
		case 'i':
			LCD_Write_String("Insuff. Fund");
			_delay_ms(500);
			break;
		case '0':
			LCD_Write_String("A...");
			_delay_ms(500);
			break;
		default:
			LCD_Write_String("Undefined Err");
			_delay_ms(500);
			break;
	}
}

void DisplayComplete()
{
	clearlcd();
	LCD_Write_String("Transaction");
	LCD_cmd(0xC0);								// move cursor to the beginning of the 2nd row
	_delay_ms(10);
	LCD_Write_String("Complete.");
	_delay_ms(500);
}

void DisplayBalance()
{
	clearlcd();
	LCD_Write_String("Balance:  ");
	_delay_ms(10);
	LCD_int_display(balance);
}

void clearlcd()
{
	LCD_cmd(0x01);			//Clear Display
	_delay_ms(10);
}

void soft_reset()
{
	do
	{
		wdt_enable(WDTO_15MS);
		for(;;)
		{
		}
	}while(0);
}

void verify_card()
{
	step=1;
	unsigned char keyV[]   = "a405m414p429s445";
	unsigned int Random= TCNT1;
	for(int k=0;k<16;k++)
	{
		verify_code[k]=Random%(9+k)+48;
		msg[k]=verify_code[k];
	}
	verify_code[16]=0;
	//Encrypting
	aes_enc_dec(msg,keyV,0);				//0 for Encryption
	for(j=0;j<16;j++)
		ciphertext[j]=msg[j];
	ciphertext[j]=0;
	usart_msg_tx(&ciphertext[0]);				//send encrypted verification message
	while(IntFlag)								//wait until feedback is received
	{
		LCD_Write_String("Verifying...");
	}
	IntFlag=1;
	if(authenticity==0)	
		{
			LCD_Write_String("Authen. Err");
			_delay_ms(500);
			soft_reset();
		}
}