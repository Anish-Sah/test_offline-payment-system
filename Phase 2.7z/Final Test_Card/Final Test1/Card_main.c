//--- F_CPU & BAUD RATE ---//
#define F_CPU		8000000UL	//--- CPU Clock Frequency
#define BAUD RATE	9600		//--- Transmission Baud Rate

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "Usart.h"
#include "Display7Seg.h"
#include "AES.h"

uint16_t balance;
unsigned char feedback;
 
unsigned char check_pw()
{
	uint16_t tran_amt;
	balance = eeprom_read_word((uint16_t *) 200);
	if(rx_data[0]=='A'&& rx_data[1]=='M'&& rx_data[2]=='P' && rx_data[3]=='S')     //1st 2nd 3rd and 4th digit act as password
	{
		tran_amt= (rx_data[6]-48)*100+(rx_data[7]-48)*10+(rx_data[8]-48);		//Calculating Transaction amount
		if(rx_data[9]=='1')												 //1: Recharge in the 10th digit
			{
				balance+=tran_amt;
				eeprom_update_word((uint16_t *) 200, balance);	//writing the balance to eeprom, in the memory address 20 in EEPROM
				return 's';											//s Feedback signal: Recharge Successful
			}
		else 
			{
				if(tran_amt<balance)					//Payment if balance is greater than Transaction amount
					{
						balance-=tran_amt;
						eeprom_update_word((uint16_t *) 200, balance);	//writing the balance to eeprom, in the memory address 20 in EEPROM
						return 's';						//s signals payment successful
					}
				else
					return 'i';							//i signals insufficient balance
			}					
	}
	else
		return '0';										//Authentication Error
}

ISR(USART_RXC_vect)
{
	usart_msg_rx();						//--- Usart Receiving
	unsigned char key2[]   = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
	  0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f}; 
	aes_enc_dec(rx_data, key2, 1);			//1 for decryption
	feedback= check_pw();
	usart_tx(feedback);
	//Send Feedback Signal
	
	//Display Transaction success or failure for 5 Seconds
	uint8_t counter=0;
	TCCR1B |= 1<<CS10;
	while(counter<40)
	{
		while(TCNT1<60000)
		{
			counter++;
			if(feedback== 's')	led_display_succ();
			if(feedback== 'i' || feedback == '0')	led_display_fail();
		}
		TCNT1 =0;
		counter ++;
	}
}

int main()
{
	//Setting interrupt
	DDRD |=1<<PIND1;
	usart_init();						//--- Usart initializing
	sei();
	//Initial initialization of the balance
	//eeprom_update_word((uint16_t*) 200, 999);
	balance = eeprom_read_word((uint16_t *) 200);		//getting balance from EEPROM
	
	while(1)
	{
		led_display(balance);
		//Jump to ISR for transaction when Receiving interrupt is triggered 
	}
	return 0;
	
}

